# Beginning SpringBoot 2


### Chapter 05 : Working with JdbcTemplate

**springboot-jdbc-demo**: This module is a SpringBoot application demonstrating how to use jdbc starter.

#### How to run?

springboot-jdbc-demo> mvn test
