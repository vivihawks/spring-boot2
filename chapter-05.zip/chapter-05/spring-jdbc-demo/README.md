# Beginning SpringBoot 2


### Chapter 05 : Working with JdbcTemplate

**spring-jdbc-demo**: This module is a sample application demonstrating how we normally use Spring and JDBC without using SpringBoot.

#### How to run?

spring-jdbc-demo> mvn test
