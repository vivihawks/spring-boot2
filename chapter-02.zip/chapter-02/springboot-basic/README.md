# Beginning SpringBoot 2


### Chapter 02 : Getting Started with SpringBoot

**springboot-basic**: This module is a basic SpringBoot web application using Maven and Gradle

#### How to run?

If you want to use **Maven** 

springboot-basic> mvn clean package spring-boot:run

If you want to use **Gradle**

springboot-basic> gradle bootRun


Go to http://localhost:8080/