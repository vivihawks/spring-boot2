# Beginning SpringBoot 2


### Chapter 10 : Web Applications with SpringBoot

**springboot-thymeleaf-demo**: This module is a SpringBoot web application demonstrating how to use Thymeleaf for view layer and file uploading.

#### How to run?


springboot-thymeleaf-demo> mvn spring-boot:run

Go to http://localhost:8080/