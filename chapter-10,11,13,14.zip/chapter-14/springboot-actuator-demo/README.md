# Beginning SpringBoot 2


### Chapter 14 : SpringBoot Actuator

**springboot-actuator-demo**: This module demonstrates SpringBoot Actuator features.

#### How to run?

springboot-actuator-demo> mvn spring-boot:run

Go to http://localhost:8080/application and from there you can see all other Actuator endpoinds.
