# Beginning SpringBoot 2


### Chapter 01 : Introduction to SpringBoot

**springmvc-jpa-demo**: This module is a web application developed using SpringMVC and JPA without using SpringBoot.

#### How to run?

springmvc-jpa-demo> mvn clean package tomcat7:run

Go to http://localhost:8080/springmvc-jpa-demo

If you want to use gradle:

springmvc-jpa-demo> gradle tomcatRunWar

Go to http://localhost:8080/springmvc-jpa-demo