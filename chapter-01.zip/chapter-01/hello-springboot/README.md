# Beginning SpringBoot 2


### Chapter 01 : Introduction to SpringBoot

**hello-springboot**: This module is a SpringBoot based web application using SpringMVC and Spring Data JPA 

#### How to run?

hello-springboot> mvn clean package spring-boot:run

Go to http://localhost:8080/