# Beginning SpringBoot 2


### Chapter 03 : Being productive with SpringBoot

**conditional**: This module is a demonstration of how to use Spring's @Conditional annotation.

Read comments in AppConfig.java to turn on/off various options.
 
#### How to run?

conditional> mvn test

conditional> mvn test -DdbType=MONGODB

