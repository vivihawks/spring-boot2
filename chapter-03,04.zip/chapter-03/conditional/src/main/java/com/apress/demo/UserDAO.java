/**
 * 
 */
package com.apress.demo;

import java.util.List;

/**
 * @author Siva
 *
 */
public interface UserDAO
{
	List<String> getAllUserNames();
}
