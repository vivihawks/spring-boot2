# Beginning SpringBoot 2


### Chapter 06 : Working with MyBatis

**springboot-mybatis-demo**: This module is a SpringBoot application demonstrating how to use MyBatis starter.

#### How to run?

springboot-mybatis-demo> mvn test
